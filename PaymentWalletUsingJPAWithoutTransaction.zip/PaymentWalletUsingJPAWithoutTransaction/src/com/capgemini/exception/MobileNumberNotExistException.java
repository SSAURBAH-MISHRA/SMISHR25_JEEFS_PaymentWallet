package com.capgemini.exception;

public class MobileNumberNotExistException extends Exception {

}
