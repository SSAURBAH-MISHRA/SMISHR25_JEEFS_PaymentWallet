package com.capgemini.exception;

public class DuplicateIdentityException extends Exception {

}
