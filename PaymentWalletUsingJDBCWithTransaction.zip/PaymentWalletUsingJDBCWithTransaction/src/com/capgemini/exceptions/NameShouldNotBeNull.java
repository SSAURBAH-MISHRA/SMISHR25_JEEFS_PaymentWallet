package com.capgemini.exceptions;

@SuppressWarnings("serial")
public class NameShouldNotBeNull extends Exception {

}
