package com.capgemini.exceptions;

@SuppressWarnings("serial")
public class DuplicateMobileNumberExistException extends Exception {

}
